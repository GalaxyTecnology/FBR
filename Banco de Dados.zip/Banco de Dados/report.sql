SELECT * FROM usuario;

SELECT nome_cidade FROM cidades WHERE nome_cidade LIKE 'Car%' ORDER BY nome_cidade DESC;

SELECT cep FROM ceps WHERE cep = '56903525';

SELECT COUNT(*) FROM ceps; 

SELECT fornecedor AS "PROVEDOR", tecnologia AS "Tipo da Conexão" FROM ip; 

SELECT DISTINCT nome_cidade FROM cidades 
WHERE nome_cidade LIKE 'Bon%'
ORDER BY nome_cidade;

SELECT i.fornecedor AS "Provedor", c.nome_cidade AS "Cidade", e.sigla_estado AS "Estado" 
FROM cidades c 
JOIN estados e 
ON c.id_estado = e.id_estado
JOIN ceps ce
ON ce.id_cidade = c.id_cidade
JOIN ip i
ON ce.cep = i.cep
WHERE e.sigla_estado = 'PE' ;

SELECT i.fornecedor AS "Provedor", c.nome_cidade AS "Cidade", e.sigla_estado AS "Estado" 
FROM cidades c 
JOIN estados e 
ON c.id_estado = e.id_estado
JOIN ceps ce
ON ce.id_cidade = c.id_cidade
JOIN ip i
ON ce.cep = i.cep
WHERE e.sigla_estado = 'PE' AND c.nome_cidade LIKE '%B%' ;

SELECT c.nome_cidade AS "Cidade", e.sigla_estado AS "Estado" 
FROM cidades c 
JOIN estados e 
ON c.id_estado = e.id_estado
WHERE e.sigla_estado = 'PE';

SELECT c.logradouro AS "Endereço", ci.nome_cidade 
AS "Cidade", e.nome_estado AS "Estado", c.cep AS "CEP"
FROM ceps c JOIN cidades ci 
ON c.id_cidade = ci.id_cidade
JOIN estados e ON c.id_estado = e.id_estado
WHERE cep >= '55000000' AND cep <= '55008000'  
GROUP BY c.logradouro, ci.nome_cidade, e.nome_estado, c.cep;

