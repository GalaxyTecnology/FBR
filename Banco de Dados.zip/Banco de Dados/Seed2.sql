BEGIN;

INSERT INTO public.usuario
VALUES (DEFAULT, 'teste', 'teste', 'José', 'fulano@uol.com.br', DEFAULT);
INSERT INTO public.usuario
VALUES (DEFAULT, 'pedro', '1234', 'Pedro', 'pedro@uol.com.br', DEFAULT);
INSERT INTO public.usuario
VALUES (DEFAULT, 'pammela', '1234', 'Pamella', 'pammela@uol.com.br', DEFAULT);
INSERT INTO public.usuario
VALUES (DEFAULT, 'george', '1234', 'George', 'george@uol.com.br', DEFAULT);
INSERT INTO public.usuario
VALUES (DEFAULT, 'rickson', '1234', 'Rickson', 'rickson@uol.com.br', DEFAULT);
INSERT INTO public.usuario
VALUES (DEFAULT, 'victoria', '1234', 'Victoria', 'victoria@uol.com.br', DEFAULT);
INSERT INTO public.usuario
VALUES (DEFAULT, 'wesley', '12345', 'Wesley', 'wesley@uol.com.br', DEFAULT);
INSERT INTO public.usuario
VALUES (DEFAULT, 'eduardo', '123456', 'Eduardo', 'eduardo@uol.com.br', DEFAULT);
INSERT INTO public.usuario
VALUES (DEFAULT, 'cleudimar', '12345', 'Cleudimar', 'cleudimar@uol.com.br', DEFAULT);
INSERT INTO public.usuario
VALUES (DEFAULT, 'geovanne', '12345', 'Geovanne', 'geovanne@uol.com.br', DEFAULT);
COMMIT;

BEGIN;
INSERT INTO public.administrador
VALUES (1,'S');
INSERT INTO public.administrador
VALUES (2,'N');
INSERT INTO public.administrador
VALUES (3,'N');
INSERT INTO public.administrador
VALUES (4,'S');
INSERT INTO public.administrador
VALUES (5,'S');
INSERT INTO public.administrador
VALUES (6,'S');
INSERT INTO public.administrador
VALUES (7,'S');
INSERT INTO public.administrador
VALUES (8,'S');
INSERT INTO public.administrador
VALUES (9,'S');
INSERT INTO public.administrador
VALUES (10,'S');
COMMIT;

BEGIN;

INSERT INTO public.ip 
VALUES (DEFAULT,'FRL-PGM032100016',55330000,'TRAVESSA HENRIQUE DIAS' ,
		's/n','','VC NET','191.240.183.252','FIBRA ÓPTICA',100,0,'85.00');
INSERT INTO public.ip 
VALUES (DEFAULT,'FRL-PGM032100010',52060615,'RUA DR. JOÃO SANTOS FILHO' ,
		'255','Lojas 36 - 37 - 38','HOTLINK','189.1.28.238','FIBRA ÓPTICA',10,10,'99.00');
INSERT INTO public.ip 
VALUES (DEFAULT,'FRL-PGM032100058',55002035,'RUA PARIS' ,
		'801','','DS TELECOM','45.167.79.107','FIBRA ÓPTICA',10,0,'85.00');
INSERT INTO public.ip 
VALUES (DEFAULT,'FRL-PGM012100022',55520000,'RUA DR. JOSÉ BEZERRA' ,
		's/n','Predio do AIA','PERNAMBUCO TELECOM','45.171.89.3','FIBRA ÓPTICA',100,0,'85.00');
INSERT INTO public.ip 
VALUES (DEFAULT,'FRL-PGM032100009',55385000,'RUA LAURENTINO DE BARROS CORREIA' ,
		'56','','PROXXIMA','177.86.92.3','FIBRA ÓPTICA',10,10,'99.00');
INSERT INTO public.ip 
VALUES (DEFAULT,'FRL-PGM032100069',55642150,'RUA DO PRADO' ,
		'1','LUC 126 E 127','ATEL TELECOM','191.5.206.211','FIBRA ÓPTICA',100,0,'85.00');
INSERT INTO public.ip 
VALUES (DEFAULT,'FRL-PGM012100099',55002035,'RUA PARIS' ,
		'801','','GOVISTA','189.127.188.108','FIBRA ÓPTICA',100,0,'85.00');
INSERT INTO public.ip 
VALUES (DEFAULT,'FRL-PGM012100016',55330000,'TRAVESSA HENRIQUE DIAS' ,
		'S/N','','AGRESTE LINK','143.202.231.122','FIBRA ÓPTICA',50,100,'95.00');
INSERT INTO public.ip 
VALUES (DEFAULT,'FRL-PGM012100086',55642150,'RUA DO PRADO' ,
		'405','','PLANETA','138.185.148.155','FIBRA ÓPTICA',100,0,'85.00');		
INSERT INTO public.ip 
VALUES (DEFAULT,'FRL-PGM032100062',55520000,'RUA DR. JOSÉ BEZERRA' ,
		's/n','PREDIO DO AIA','LOGNET','45.185.212.14','FIBRA ÓPTICA',100,0,'85.00');
		
COMMIT;		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		