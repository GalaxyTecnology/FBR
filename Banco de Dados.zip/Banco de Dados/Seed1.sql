COPY public.estados
FROM 'C:\CEP\states.csv'
DELIMITER ','
;

COPY public.cidades
FROM 'C:\CEP\cities.csv'
DELIMITER ','
;

COPY public.ceps
FROM 'C:\CEP\ceps.csv'
DELIMITER ','
;