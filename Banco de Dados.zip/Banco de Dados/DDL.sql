CREATE TABLE usuario (
  	usuario_id INTEGER PRIMARY KEY GENERATED ALWAYS AS IDENTITY,
  	usuario varchar(200)NOT NULL,
 	senha varchar(255) NOT NULL,
  	nome varchar(255) NOT NULL,
  	email varchar(120) NOT NULL,
  	data_cadastro timestamp DEFAULT CURRENT_TIMESTAMP
) ;

CREATE TABLE administrador (
	usuario_id INTEGER NOT NULL,
	cadastra_usuario CHAR(1) NOT NULL,
	FOREIGN KEY (usuario_id) REFERENCES usuario (usuario_id)
);

CREATE TABLE estados (
	id_estado INTEGER PRIMARY KEY,
	nome_estado varchar (30) NOT NULL,
	sigla_estado char (2) NOT NULL
);

CREATE TABLE cidades (
	id_cidade INTEGER PRIMARY KEY,
	nome_cidade varchar (80) NOT NULL,
	id_estado int, 
	FOREIGN KEY (id_estado) REFERENCES estados (id_estado)
);

CREATE TABLE ceps (
	cep INTEGER PRIMARY KEY,
	logradouro varchar(100) NOT NULL,
	bairro varchar(100) NOT NULL,
	id_cidade int, 
	id_estado int, 
	FOREIGN KEY (id_cidade) REFERENCES cidades (id_cidade),
	FOREIGN KEY (id_estado) REFERENCES estados (id_estado)
);


CREATE TABLE ip (
	id_ip INTEGER PRIMARY KEY GENERATED ALWAYS AS IDENTITY,
	registro varchar (16) NOT NULL,
	cep int,
	endereco varchar(100),
	numero varchar(10) NOT NULL,
	complento varchar(80),
	fornecedor varchar(25) NOT NULL,
	ip varchar(16) NOT NULL,
	tecnologia varchar (20) NOT NULL,
	banda_up integer,
	banda_down integer,
	sla varchar(6),
	FOREIGN KEY (cep) REFERENCES ceps (cep)
);

















