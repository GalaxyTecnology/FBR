<?php
session_start();
include('conexao.php'); 

if(empty($_POST['usuario']) || empty($_POST['senha'])) {
	header('Location: index.php');
	exit();
}

$usuario = $_POST['usuario'];
$senha = $_POST['senha'];

$sql_code = "SELECT * FROM usuario WHERE usuario = '$usuario'";
$sql_exec = $conexao->query($sql_code) or die ($conexao->error);

$usuario = $sql_exec->fetch_assoc();

$isValidPassword = password_verify($senha, $usuario['senha']);
if ($isValidPassword == true) {
	$_SESSION['usuario'] = $usuario['usuario'];
	header('Location: painel.php');
	exit();
} else {
	$_SESSION['nao_autenticado'] = true;
	header('Location: index.php');
	exit();
}