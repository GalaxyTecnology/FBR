<?php
define('HOST', '127.0.0.1');
define('USUARIO', 'u831952228_master');
define('SENHA', 'Madimbu@2019');
define('DB', 'u831952228_login');

$conexao = mysqli_connect(HOST, USUARIO, SENHA, DB) or die ('Não foi possível conectar');
?>